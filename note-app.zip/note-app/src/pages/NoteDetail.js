import React, { useContext } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { NotesContext } from '../context/NotesContext';

function NoteDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { notes, deleteNote } = useContext(NotesContext);
  
  // Find the note with the matching id
  const note = notes.find(note => note.id === id);
  
  // Handle case where note is not found
  if (!note) {
    return (
      <div className="note-not-found">
        <h2>Note Not Found</h2>
        <p>The note you're looking for doesn't exist.</p>
        <Link to="/">Back to Notes</Link>
      </div>
    );
  }
  
  // Function to handle note deletion
  const handleDelete = () => {
    if (window.confirm('Are you sure you want to delete this note?')) {
      deleteNote(id);
      navigate('/');
    }
  };
  
  // Format dates
  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleString();
  };

  return (
    <div className="note-detail-container">
      <div className="note-detail-header">
        <h2>{note.title}</h2>
        <div className="note-meta">
          <span className={`priority priority-${note.priority}`}>
            {note.priority.charAt(0).toUpperCase() + note.priority.slice(1)} Priority
          </span>
          <span className="category">{note.category}</span>
        </div>
      </div>
      
      <div className="note-content">
        <p>{note.content}</p>
      </div>
      
      <div className="note-timestamps">
        <p>Created: {formatDate(note.createdAt)}</p>
        <p>Last updated: {formatDate(note.updatedAt)}</p>
      </div>
      
      <div className="note-actions">
        <Link to="/" className="back-btn">Back to Notes</Link>
        <Link to={`/edit/${note.id}`} className="edit-btn">Edit</Link>
        <button onClick={handleDelete} className="delete-btn">Delete</button>
      </div>
    </div>
  );
}

export default NoteDetail;