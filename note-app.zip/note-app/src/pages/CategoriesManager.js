import React, { useState, useContext } from 'react';
import { Link } from 'react-router-dom';
import { NotesContext } from '../context/NotesContext';

function CategoriesManager() {
  const { categories, addCategory, deleteCategory, notes } = useContext(NotesContext);
  const [newCategory, setNewCategory] = useState('');
  const [error, setError] = useState('');

  const handleAddCategory = (e) => {
    e.preventDefault();
    
    // Validation
    if (!newCategory.trim()) {
      setError('Category name cannot be empty');
      return;
    }
    
    if (categories.includes(newCategory.trim())) {
      setError('Category already exists');
      return;
    }
    
    addCategory(newCategory.trim());
    setNewCategory('');
    setError('');
  };

  const handleDeleteCategory = (category) => {
    // Count notes with this category
    const notesWithCategory = notes.filter(note => note.category === category).length;
    
    if (notesWithCategory > 0) {
      alert(`Cannot delete category "${category}" because it's used by ${notesWithCategory} note(s).`);
      return;
    }
    
    if (window.confirm(`Are you sure you want to delete category "${category}"?`)) {
      const deleted = deleteCategory(category);
      if (!deleted) {
        alert(`Cannot delete category "${category}" because it's in use.`);
      }
    }
  };

  return (
    <div className="categories-manager-container">
      <div className="categories-header">
        <h2>Manage Categories</h2>
        <Link to="/" className="back-btn">Back to Notes</Link>
      </div>
      
      <div className="categories-form">
        <form onSubmit={handleAddCategory}>
          <div className="form-group">
            <label htmlFor="newCategory">Add New Category</label>
            <div className="input-group">
              <input
                type="text"
                id="newCategory"
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                placeholder="Enter category name"
              />
              <button type="submit" className="add-category-btn">Add</button>
            </div>
            {error && <span className="error">{error}</span>}
          </div>
        </form>
      </div>
      
      <div className="categories-list">
        <h3>Current Categories</h3>
        {categories.length > 0 ? (
          <ul>
            {categories.map(category => (
              <li key={category} className="category-item">
                <span>{category}</span>
                <span className="category-count">
                  {notes.filter(note => note.category === category).length} notes
                </span>
                <button 
                  onClick={() => handleDeleteCategory(category)}
                  className="delete-category-btn"
                  disabled={notes.filter(note => note.category === category).length > 0}
                >
                  Delete
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <p>No categories found. Add your first category.</p>
        )}
      </div>
    </div>
  );
}

export default CategoriesManager;