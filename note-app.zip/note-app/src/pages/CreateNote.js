import React, { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { NotesContext } from '../context/NotesContext';

function CreateNote() {
  const { addNote, categories } = useContext(NotesContext);
  const navigate = useNavigate();
  
  const [note, setNote] = useState({
    title: '',
    content: '',
    category: categories[0],
    priority: 'medium'
  });
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNote(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!note.title.trim()) {
      newErrors.title = 'Title is required';
    }
    
    if (!note.content.trim()) {
      newErrors.content = 'Content is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (validateForm()) {
      addNote(note);
      navigate('/');
    }
  };

  return (
    <div className="create-note-container">
      <h2>Create New Note</h2>
      
      <form onSubmit={handleSubmit} className="note-form">
        <div className="form-group">
          <label htmlFor="title">Title</label>
          <input
            type="text"
            id="title"
            name="title"
            value={note.title}
            onChange={handleChange}
            placeholder="Note title"
          />
          {errors.title && <span className="error">{errors.title}</span>}
        </div>
        
        <div className="form-group">
          <label htmlFor="category">Category</label>
          <select
            id="category"
            name="category"
            value={note.category}
            onChange={handleChange}
          >
            {categories.map(category => (
              <option key={category} value={category}>{category}</option>
            ))}
          </select>
        </div>
        
        <div className="form-group">
          <label htmlFor="priority">Priority</label>
          <select
            id="priority"
            name="priority"
            value={note.priority}
            onChange={handleChange}
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
        </div>
        
        <div className="form-group">
          <label htmlFor="content">Content</label>
          <textarea
            id="content"
            name="content"
            value={note.content}
            onChange={handleChange}
            placeholder="Note content"
            rows="10"
          />
          {errors.content && <span className="error">{errors.content}</span>}
        </div>
        
        <div className="form-preview">
          <h3>Preview</h3>
          <div className="preview-content">
            <h4>{note.title || 'Untitled Note'}</h4>
            <p className="preview-category">{note.category}</p>
            <p>{note.content || 'Your note content will appear here'}</p>
          </div>
        </div>
        
        <div className="form-actions">
          <button type="button" onClick={() => navigate('/')} className="cancel-btn">
            Cancel
          </button>
          <button type="submit" className="save-btn">
            Save Note
          </button>
        </div>
      </form>
    </div>
  );
}

export default CreateNote;