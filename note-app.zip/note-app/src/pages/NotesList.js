import React, { useContext, useState } from 'react';
import { Link } from 'react-router-dom';
import { NotesContext } from '../context/NotesContext';

function NotesList() {
  const { notes, categories, deleteNote } = useContext(NotesContext);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [sortBy, setSortBy] = useState('updatedAt');
  const [sortOrder, setSortOrder] = useState('desc');

  // Filter notes based on search term and category
  const filteredNotes = notes.filter(note => {
    const matchesSearch = note.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          note.content.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory ? note.category === selectedCategory : true;
    return matchesSearch && matchesCategory;
  });

  // Sort the filtered notes
  const sortedNotes = [...filteredNotes].sort((a, b) => {
    if (sortBy === 'title') {
      return sortOrder === 'asc' 
        ? a.title.localeCompare(b.title)
        : b.title.localeCompare(a.title);
    } else if (sortBy === 'updatedAt') {
      return sortOrder === 'asc'
        ? new Date(a.updatedAt) - new Date(b.updatedAt)
        : new Date(b.updatedAt) - new Date(a.updatedAt);
    } else if (sortBy === 'priority') {
      const priorityValue = { high: 3, medium: 2, low: 1 };
      return sortOrder === 'asc'
        ? priorityValue[a.priority] - priorityValue[b.priority]
        : priorityValue[b.priority] - priorityValue[a.priority];
    }
    return 0;
  });

  // Toggle sort order
  const toggleSortOrder = () => {
    setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
  };

  return (
    <div className="notes-list-container">
      <div className="notes-list-header">
        <h2>My Notes</h2>
        <Link to="/categories" className="categories-btn">Manage Categories</Link>
        <Link to="/create" className="add-note-btn">Add New Note</Link>
      </div>
      
      <div className="notes-filters">
        <input
          type="text"
          placeholder="Search notes..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="search-input"
        />
        
        <select 
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="category-select"
        >
          <option value="">All Categories</option>
          {categories.map(category => (
            <option key={category} value={category}>{category}</option>
          ))}
        </select>
      </div>
      
      <div className="notes-sort">
        <label>Sort by:</label>
        <select 
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
          className="sort-select"
        >
          <option value="updatedAt">Last Updated</option>
          <option value="title">Title</option>
          <option value="priority">Priority</option>
        </select>
        
        <button 
          onClick={toggleSortOrder} 
          className="sort-order-btn"
        >
          {sortOrder === 'asc' ? '↑ Ascending' : '↓ Descending'}
        </button>
      </div>
      
      <div className="notes-grid">
        {sortedNotes.length > 0 ? (
          sortedNotes.map(note => (
            <div key={note.id} className="note-card">
              <h3>{note.title}</h3>
              <div className="note-badges">
                <span className="note-category">{note.category}</span>
                <span className={`note-priority priority-${note.priority}`}>
                  {note.priority}
                </span>
              </div>
              <p className="note-preview">
                {note.content.substring(0, 100)}
                {note.content.length > 100 ? '...' : ''}
              </p>
              <div className="note-footer">
                <small>
                  {new Date(note.updatedAt).toLocaleDateString()}
                </small>
                <div className="note-actions">
                  <Link to={`/note/${note.id}`} className="view-btn">View</Link>
                  <Link to={`/edit/${note.id}`} className="edit-btn">Edit</Link>
                  <button 
                    className="delete-btn"
                    onClick={() => {
                      if(window.confirm('Are you sure you want to delete this note?')) {
                        deleteNote(note.id);
                      }
                    }}
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          ))
        ) : (
          <p className="no-notes">No notes found.</p>
        )}
      </div>
    </div>
  );
}

export default NotesList;