import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { NotesProvider } from './context/NotesContext';
import './App.css';

// Import pages
import NotesList from './pages/NotesList';
import NoteDetail from './pages/NoteDetail';
import CreateNote from './pages/CreateNote';
import EditNote from './pages/EditNote';
import CategoriesManager from './pages/CategoriesManager';

function App() {
  return (
    <NotesProvider>
      <Router>
        <div className="App">
          <header className="App-header">
            <h1>Note App</h1>
          </header>
          <main>
            <Routes>
              <Route path="/" element={<NotesList />} />
              <Route path="/note/:id" element={<NoteDetail />} />
              <Route path="/create" element={<CreateNote />} />
              <Route path="/edit/:id" element={<EditNote />} />
              <Route path="/categories" element={<CategoriesManager />} />
            </Routes>
          </main>
        </div>
      </Router>
    </NotesProvider>
  );
}

export default App;