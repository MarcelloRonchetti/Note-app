import React, { createContext, useReducer, useEffect } from 'react';

// Initial state
const initialState = {
  notes: [],
  categories: ['Work', 'Personal', 'Study']
};

// Create context
export const NotesContext = createContext();

// Reducer function
function notesReducer(state, action) {
  switch (action.type) {
    case 'SET_NOTES':
      return { ...state, notes: action.payload };
    case 'ADD_NOTE':
      return { ...state, notes: [...state.notes, action.payload] };
    case 'DELETE_NOTE':
      return { ...state, notes: state.notes.filter(note => note.id !== action.payload) };
    case 'UPDATE_NOTE':
      return { 
        ...state, 
        notes: state.notes.map(note => 
          note.id === action.payload.id ? action.payload : note
        ) 
      };
    case 'ADD_CATEGORY':
      return { ...state, categories: [...state.categories, action.payload] };
    case 'DELETE_CATEGORY':
      return { ...state, categories: state.categories.filter(category => category !== action.payload) };
    case 'SET_CATEGORIES':
      return { ...state, categories: action.payload };
    default:
      return state;
  }
}

// Provider component
export const NotesProvider = ({ children }) => {
  const [state, dispatch] = useReducer(notesReducer, initialState);

  // Load notes from localStorage on initial load
  useEffect(() => {
    const storedNotes = localStorage.getItem('notes');
    if (storedNotes) {
      dispatch({ type: 'SET_NOTES', payload: JSON.parse(storedNotes) });
    }
    
    const storedCategories = localStorage.getItem('categories');
    if (storedCategories) {
      dispatch({ type: 'SET_CATEGORIES', payload: JSON.parse(storedCategories) });
    }
  }, []);

  // Save notes to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('notes', JSON.stringify(state.notes));
  }, [state.notes]);
  
  // Save categories to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('categories', JSON.stringify(state.categories));
  }, [state.categories]);

  // Action functions
  const addNote = (note) => {
    const newNote = {
      ...note,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    dispatch({ type: 'ADD_NOTE', payload: newNote });
  };

  const updateNote = (note) => {
    const updatedNote = {
      ...note,
      updatedAt: new Date().toISOString()
    };
    dispatch({ type: 'UPDATE_NOTE', payload: updatedNote });
  };

  const deleteNote = (id) => {
    dispatch({ type: 'DELETE_NOTE', payload: id });
  };
  
  const addCategory = (category) => {
    if (!state.categories.includes(category)) {
      dispatch({ type: 'ADD_CATEGORY', payload: category });
    }
  };
  
  const deleteCategory = (category) => {
    // Don't delete if there are notes using this category
    const notesWithCategory = state.notes.filter(note => note.category === category);
    if (notesWithCategory.length === 0) {
      dispatch({ type: 'DELETE_CATEGORY', payload: category });
      return true;
    }
    return false;
  };

  return (
    <NotesContext.Provider
      value={{
        notes: state.notes,
        categories: state.categories,
        addNote,
        updateNote,
        deleteNote,
        addCategory,
        deleteCategory
      }}
    >
      {children}
    </NotesContext.Provider>
  );
};