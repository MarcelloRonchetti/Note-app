import React from 'react';
import { Link, useLocation } from 'react-router-dom';

function Navigation() {
  const location = useLocation();
  
  return (
    <nav className="main-nav">
      <ul>
        <li className={location.pathname === '/' ? 'active' : ''}>
          <Link to="/">All Notes</Link>
        </li>
        <li className={location.pathname === '/create' ? 'active' : ''}>
          <Link to="/create">New Note</Link>
        </li>
        <li className={location.pathname === '/categories' ? 'active' : ''}>
          <Link to="/categories">Categories</Link>
        </li>
      </ul>
    </nav>
  );
}

export default Navigation;